# Install


This playbook installing Airflow by user airflow in virtual environment (.venv)

## Prepare to run playbook
Before run playbook, please edit some config files:

1. Add hosts to **_inventory/hosts_** file

2. Type Airflow version you need for istall here: **_roles/airflow/defaults/main.yml_** in section "airflow_version"
   
3. Replace user credentials in **_roles/airflow/defaults/main.yml_** in section # UI User:

```
# UI User
airflow_login_username     : BorsoevRV  
airflow_login_firstname    : Roman  
airflow_login_lastname     : Borsoev  
airflow_login_role         : Admin  
airflow_login_email        : roman.borsoev@rusal.com  
airflow_login_password     : SomeStr0ngPa$$w0rd!
```
## Run playbook
To run playbook, enter command:
```
ansible-playbook airflow.yml
```