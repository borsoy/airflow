import sys
from airflow import settings
from flask_appbuilder.security.sqla.models import User
from flask_appbuilder.security.sqla.models import Role
from werkzeug.security import generate_password_hash

def create_user(username, firstname, lastname, email, password, role_name):
    session = settings.Session()

    # Проверка, существует ли пользователь
    user = session.query(User).filter(User.username == username).first()
    if user:
        print(f"Пользователь '{username}' уже существует.")
        session.close()
        sys.exit(0)

    # Поиск роли
    role = session.query(Role).filter(Role.name == role_name).first()
    if not role:
        print(f"Роль '{role_name}' не найдена.")
        session.close()
        sys.exit(1)

    # Создание нового пользователя
    new_user = User()
    new_user.username = username
    new_user.first_name = firstname
    new_user.last_name = lastname
    new_user.email = email
    new_user.password = generate_password_hash(password)
    new_user.roles.append(role)

    # Добавление пользователя в сессию и коммит
    session.add(new_user)
    session.commit()
    print(f"Пользователь '{username}' успешно создан.")
    session.close()

if __name__ == "__main__":
    create_user(
        username='rem4',
        firstname='Roman',
        lastname='Borsoev',
        email='4@rusal.com',
        password='O9fjwsa1',
        role_name='Admin'
    )

