airflow users create --username rem \
                        --firstname Roman \
                        --lastname Borsoev \
                        --role Admin \
                        --email roman.borsoev@rusal.com \
                        --password O9fjwsa1